INSTRUCTIONS TO USE THE FILE:

NO NEED TO RUN IT INSIDE ANY COMPILER
JUST CLICK THIS LINK (or copy it to any browser):
https://image-compression-alpaljabar.streamlit.app/